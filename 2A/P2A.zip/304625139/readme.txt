For our project. We divided the work between both Natasha, Caroline, Bibek, and I in the following way. Caroline parsed the text. Natasha wrote the unigram code. 
Bibek handled the bigram and trigram code. Monil wrote the code to read the JSON and run the function. Bibek decided to create a function 
makeNGrams, which made the implementation of unigram, bigram, and trigram, a lot more straightforward. We acknowledge that our implementation 
is not perfect, but based on the Law of Diminishing Returns we decided to stop where we have. 
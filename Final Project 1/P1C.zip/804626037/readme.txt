Readme:

Caroline:
finished the insertion pages 
added search page/browse pages
add type checks and eror checkings

Natasha:
started with add movie and add person pages
made styles for the project
recorded video project
<head>
<link rel="stylesheet" href="styling.css">
<?php include('navigation.php') ?>

<div class = "home" >
  <div class = "header" >Welcome to... OUR WEBSITE!</div>
  <img class = "us" src = "the_developers.jpg" />
  <div>(those are the developers with a cute little corgi)</div>
</div>


</head>
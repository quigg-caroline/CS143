<head>
<link rel="stylesheet" href="styling.css">

<div class="nav">
  <a href="homepage.php">Home</a>
  
  <a href="search.php">Search</a>

  <div class="main-drop">
    <button class="dropbtn">Add New Content</button>
    <div class="dropdown">
      <a href="add-person.php">Actor/Director</a>
      <a href="add-movie.php">Movie Information</a>
      <a href="add-review.php">Movie Review</a>
      <a href="add-actorrelation.php">Actor-Movie Relation</a>
      <a href="add-moviedirector.php">Movie-Director Relation</a>
    </div>
  </div> 

</div>
</head>